BEEP_HTML = BEEP = '[beep]'
